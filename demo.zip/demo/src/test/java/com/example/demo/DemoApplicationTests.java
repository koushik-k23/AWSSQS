package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


//UNIT TEST FILE WITH 3 CASES


@SpringBootTest
class DemoApplicationTests {

	@Test
	void contextLoads() {
		DemoApplication da = new DemoApplication();
		da.sendMessageToQueue("red");

		da.sendMessageToQueue("blue");

		da.sendMessageToQueue("Ferrari");
	}

}
