package com.example.demo;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.aws.autoconfigure.context.ContextStackAutoConfiguration;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.*;

@SpringBootApplication(exclude = {ContextStackAutoConfiguration.class})
//@SpringBootApplication
@RestController
public class DemoApplication {

	@Autowired
	private QueueMessagingTemplate queueMessagingTemplate;

	@Value("${cloud.aws.end-point.uri}")
	private String endpoint;

	//@GetMapping("/send/{message}")
	@RequestMapping(value = "/send/{message}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String sendMessageToQueue(@PathVariable String message) {
		Gson gson= new GsonBuilder().create();
		System.out.println(gson.toJson(message)); //TESTS
		queueMessagingTemplate.send(endpoint, MessageBuilder.withPayload(gson.toJson(message)).build());
		System.out.println(JSONObject.quote(message)); //TESTS
		System.out.println(message); //TEST

		return gson.toJson(message);
	}
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
