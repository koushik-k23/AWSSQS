***********CODE CHALLENGE***********

Requirement: Write an application to connect to AWS SQS (any queue name/type ) and send a JSON format message.
also implement unit tests for your code. The code should be written by Java SpringBoot.

Created a SpringBoot application folder with AWS Core and SQS dependencies.

application.yml contains the credentials I used for this challenge.
Found in the demo/src/resources/application.yml

Feel free to use my credentials or create your own group. The terminal outputs the result, or you can go on AWS console to view the message.
I also used Postman for debugging purposes, you may also use that.

Thank you,
Koushik Krishnan (647-979-3308)